# MRI BRAIN TUMOR > BRAINTUMORSAMPLE1.0
https://universe.roboflow.com/hashira-fhxpj/mri-brain-tumor

Provided by a Roboflow user
License: CC BY 4.0

